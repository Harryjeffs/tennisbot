    'use strict';
    require('dotenv').config();

    // The Firebase Admin SDK to access the Firebase Realtime Database.
    const admin = require('firebase-admin');

    admin.initializeApp({
        credential: admin.credential.applicationDefault(),
        databaseURL: process.env.DATABASE_URL
    });

    // Define database variable linked to the Realtime Database.
    var db = admin.database();

    const { WebClient } = require('@slack/web-api');

    // An access token (from your Slack app or custom integration - xoxp, xoxb)
    const token = process.env.SLACK_TOKEN;

    const web = new WebClient(token);

    // This argument can be a channel ID, a DM ID, a MPDM ID, or a group ID
    const conversationId = 'CQSHZE09X';


    var ref = db.ref("playersgame/");

    var playersRef = db.ref("players");

    ref.once("child_added", function(snapshot) {
        var gameData = snapshot.val();
        playersRef.orderByChild(gameData.t1p1).on("value", function(snapshot) {
            var playerOneData = snapshot.val();
            playersRef.orderByChild(gameData.t2p1).on("value", function(snapshot) {
                var secondsOneData = snapshot.val();
                (async () => {
                    var message = playerOneData.name + " just played " + secondsOneData.name + " and won  " + gameData.t1_points + " games  to " + gameData.t2_points;
                    // See: https://api.slack.com/methods/chat.postMessage
                    await web.chat.postMessage({channel: conversationId, text: message});
                })();
            });
        });
    });